#!/bin/sh

# Don't execute this script outside of unshare -m scope!

. ./installer/utilities.sh.inc
. ./installer/verifier.sh.inc

verification_timeout=90

verify "$@" "$verification_timeout"
