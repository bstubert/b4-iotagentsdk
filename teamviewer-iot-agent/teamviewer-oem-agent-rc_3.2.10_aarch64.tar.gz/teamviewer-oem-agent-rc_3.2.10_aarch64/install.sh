#!/bin/sh

parseOptionsAndInstall() {
	local force_overwrite=false
	local keep_configs=true

	local install_prefix="/opt"
	# by default install var at the same directory together with all the other installation files
	local var_prefix=
	local run_dir="/run"

	local package_name="$PACKAGE_NAME"
	local package_version="$PACKAGE_VERSION"
	local daemon="$DAEMON"
	# at the moment there is inconsistency between package name and file structure, we can't use package_name there. For now always use "teamviewer-iot-agent"
	local package_install_name="teamviewer-iot-agent"

	local usage="
Usage:
$(basename $0) [options]

$package_name installation script (v$package_version)

Options:
	-h, --help
		Display this text.

	-f, --force
		Forcefully overwrite previous installations

	-nk, --no-keep-configs
		Don't try to copy old configuration files (global.conf, local.conf) from previous installations.
		New configs would be created.
		Default: copy configs from previous installations.
		Look into /var/lib/$package_install_name/global.conf and current installation directory for configuration files.

	-ip, --install-prefix <install_prefix>
		Directory to contain all persistent files.
		Files are written to <install_prefix>/$package_install_name
		Default: $install_prefix

	-vp, --var-prefix <var_prefix>
		Place var outside of installation directory.
		Commonly changeable files are written to <var_prefix>/var/(crash|lib|log)/$package_install_name
		Default: none (put var in installation directory)

	-rd, --run-dir <run_dir>
		Path to directory with runtime files.
		Default: $run_dir
"

	# options parsing
	while [ $# -gt 0 ] ; do
		case "$1" in
			-h | --help)
				echo "$usage"
				exit 0
				;;
			-f | --force)
				force_overwrite=true
				;;
			-nk | --no-keep-configs)
				keep_configs=false
				;;
			-ip | --install-prefix)
				shift
				install_prefix="$(abspath "$1")"
				;;
			-vp | --var-prefix)
				shift
				var_prefix="$(abspath "$1")"
				;;
			-rd | --run-dir)
				shift
				run_dir="$(abspath "$1")"
				;;
			*)
				echo "Error: unknown option: $1" >&2
				echo "$usage" >&2
				exit 1
				;;
		esac
		shift
	done

	stateMachineStartInstall "$package_name" "$package_version" "$daemon" "$package_install_name" "$install_prefix" "$var_prefix" "$run_dir" "$force_overwrite" "$keep_configs" || die "Error: installation failed"
	echo "Installation complete"
}

# Check if debug mode has been chosen
if [ $TV_DEBUG ]; then
	set -x
fi

# cd in a subshell to preserve PWD
(
	# set working directory
	cd "$(dirname "$(readlink -f -- "$0")")"

	. ./etc/default/teamviewer
	. ./installer/utilities.sh.inc
	. ./installer/states.sh.inc
	. ./installer/state_machine.sh.inc

	assertIsRoot
	parseOptionsAndInstall "$@"
)
